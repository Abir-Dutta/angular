import { Component, OnInit } from '@angular/core';
import { EmployeelistService } from '../employeelist.service';
import {ActivatedRoute,Router} from '@angular/router'

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  public employeeList = [];
  public employeePosts;
  public selectedId:number;

  constructor(private _employeeService: EmployeelistService,private _activatedroute:ActivatedRoute, private _router:Router) { }

  ngOnInit() {
    this._employeeService.getEmployees().subscribe(data=>this.employeeList=data);
    this._activatedroute.paramMap.subscribe(item=>{
      this.selectedId = parseInt( item.get('id'));
    })

  }
  onSelect(empid){
  //  this.employeePosts = this._employeeService.getEmployeePosts(empId).subscribe(data=>this.employeePosts=data);
  //this._router.navigate(['/employeeDet',empid])
  this._router.navigate([empid],{relativeTo:this._activatedroute});
  }
  isSelected(emp){
    return emp.id === this.selectedId
  }
}
