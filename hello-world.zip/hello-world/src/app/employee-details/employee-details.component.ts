import { Component, OnInit } from '@angular/core';
import { EmployeelistService } from '../employeelist.service';
import {ActivatedRoute,Router, ParamMap} from '@angular/router'

@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})
export class EmployeeDetailsComponent implements OnInit {

  public employeeList=[];
  public empId :number;
  constructor(private _employeeService:EmployeelistService,
    private _activatedRoute :ActivatedRoute,
    private _router:Router
  ) { }

  ngOnInit() {
   
//    let id = parseInt(this._activatedRoute.snapshot.paramMap.get('id'))
  //  this.empId=id;
  this._activatedRoute.paramMap.subscribe((params:ParamMap)=>{
    let id = parseInt(params.get('id'));
    this.empId=id;
    console.log(this.empId);
    if(isNaN(this.empId))
    this._employeeService.getEmployees().subscribe(data=>this.employeeList = data);
    else
    this.employeeList =  this._employeeService.getEmployeeByID(this.empId);

    console.log(this.employeeList);
  })
   
   
  }
  goToPrev(){
    console.log('inprev')
    this._router.navigate(['/employees',this.empId-1]);
  }
  goToNext(){
    console.log('innext')
    this._router.navigate(["/employees",this.empId+1]);
  }
  goBack(){
    this._router.navigate(["../",{id:this.empId?this.empId:null}]);
  }
}
