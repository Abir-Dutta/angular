import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

 
@Injectable({
  providedIn: 'root'
})
export class EmployeelistService {

  constructor(private _http:HttpClient) { }

  getEmployees():Observable<object[]>{
    return this._http.get<object[]>("https://jsonplaceholder.typicode.com/users"); 
  } 
  getEmployeeByID(employeeId):object[]{
    let employeeList =  this._http.get<object[]>("https://jsonplaceholder.typicode.com/users/");
    let employeeFilter;
    var employeeDet=[];
     employeeList.toPromise().then(t=>{ t.forEach(item=>{
       if(item['id'] == employeeId)
        //  { employeeDet = item;
        //   console.log(item)
        employeeDet.push(item);
         //}
    })})
    return employeeDet;
  }
}
// export interface IEmployee{
//   id: number;
//   name:string;
//   address:object;
// }
