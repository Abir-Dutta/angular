import { NgModule } from '@angular/core';
import { Routes,RouterModule } from '@angular/router';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';

const routes:Routes=[
  {path:"",redirectTo:"/employees",pathMatch:"full"},
  {path:'employees',component:EmployeeListComponent},
  {path:'employeeDet',component:EmployeeDetailsComponent},
  {path:'employees/:id',component:EmployeeDetailsComponent},

  {path:"**",component:PagenotfoundComponent}
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  declarations: []
})
export class AppRoutingModule { }

export const routingComponents =[EmployeeListComponent,EmployeeDetailsComponent]