import { Component } from '@angular/core';
import { Users } from './users';

import { EnrollmentService } from './enrollment.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  public topics=['ang','rec','vu']
  public userModel = new Users('abir',"abir.c@g.com",3333333333,'default','morning',true )
 public validError =true;
 constructor(private _enrollService:EnrollmentService){}
validTopic(value)
{
  if(value == 'default'|| !value)
  this.validError =true;
  else 
  this.validError =false;
}
onSubmit(){
  console.log(this.userModel)
  this._enrollService.enroll(this.userModel).subscribe(
    data=>console.log(data),
    error=>console.log(error)
  )
}
}
